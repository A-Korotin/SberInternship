# Запуск программы
``java -jar cities.jar {path/to/file.csv}``
